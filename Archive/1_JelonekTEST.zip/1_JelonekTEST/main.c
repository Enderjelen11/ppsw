int iLoopCtr;
int iPlusCounter;
int iMinusCounter;

int main()
{
		iPlusCounter=10;
		iMinusCounter = 10;
		for (iLoopCtr=0 ; iLoopCtr<5; iLoopCtr++)
			{
			iPlusCounter=iPlusCounter+3;
			iMinusCounter=iMinusCounter-3;
			}
}